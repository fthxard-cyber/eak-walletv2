EAK WALLET — PAKET SIAP GITHUB PAGES

Isi paket:
- index.html
- manifest.webmanifest
- sw.js
- icons/icon-192.png
- icons/icon-512.png

PENTING:
1. Ekstrak ZIP ini.
2. Upload isi folder EAK_WALLET_READY ke ROOT repository GitHub (bukan ZIP-nya).
3. Pastikan struktur folder tetap sama seperti di bawah.
4. Jangan hapus repository lama atau ganti alamat GitHub Pages agar data localStorage lama tetap berpeluang terbaca.
5. Jangan gunakan Clear storage / Hapus data situs.

Struktur yang benar:
index.html
manifest.webmanifest
sw.js
icons/
  icon-192.png
  icon-512.png

Catatan: ini adalah PWA untuk dipasang melalui Chrome, bukan file APK Android.
